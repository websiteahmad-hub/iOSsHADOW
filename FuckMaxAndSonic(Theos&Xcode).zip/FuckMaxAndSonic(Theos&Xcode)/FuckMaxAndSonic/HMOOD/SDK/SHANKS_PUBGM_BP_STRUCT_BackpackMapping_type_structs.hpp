// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_BackpackMapping_type
{
	int                                                ItemIDLv1_0_21A3A0400039E85B0FB4B5AE02FC6161;              
	int                                                ItemIDLv3_4_21A5A0C00039E85D0FB4B5A802FC6163;              
	int                                                SkinID_5_0CC9E5002CE60FA0348CD8800DC46CC4;                 
	int                                                ItemIDLv2_6_21A4A0800039E85C0FB4B5AF02FC6162;              
	int                                                SkinItemIDLv1_8_54E5658067900F920ABA96CA085B62E1;          
	int                                                SkinItemIDLv3_9_54E7660067900F940ABA96CC085B62E3;          
	int                                                LobbyShowItemID_10_2F22E9C00E7C61770577495A0A75F1B4;       
	int                                                SkinItemIDLv2_11_54E665C067900F930ABA96CD085B62E2;         
};

}

