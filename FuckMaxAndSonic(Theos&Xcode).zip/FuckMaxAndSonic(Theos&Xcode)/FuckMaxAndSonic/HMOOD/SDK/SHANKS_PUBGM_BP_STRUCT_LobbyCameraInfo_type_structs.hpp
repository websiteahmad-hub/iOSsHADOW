// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_LobbyCameraInfo_type
{
	struct FString                                     FieldOfView_0_774965C01E82608B78610A1F0CEEDE07;            
	struct FString                                     CameraLocationWidth_1_2795B9402C37D69925FC607507CC5AB8;    
	struct FString                                     CameraLocation_2_337EB9401C40211F6EB5E73A0F1A116E;         
	struct FString                                     CameraScale_3_187545000777A7B8563DCE430BD94005;            
	struct FString                                     CameraLocationX_4_0D8E2F407AB6F6691CDF865C01A117C8;        
	int                                                CameraID_5_2E8DAE400C973D5F0716503A0A82BED4;               
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     BlendTime_6_48FF35C029EC8B7B17E35E2A01AA1EF5;              
	struct FString                                     ProjectMode_7_05044FC04CBC5C8904E0C53F08075A45;            
	struct FString                                     CameraRotation_8_1901DF00292BF94210F0DE080C2A13CE;         
	struct FString                                     CameraAnimationPath_9_4B7A7640586729291B2F6F2408CB7BE8;    
	struct FString                                     CameraAnimationPathLong_10_3EB85A40709683A7360F690B0BE5FF37; 
	struct FString                                     AvatarPosition_11_2DCEE5C039B936A35A436F3D04B414DE;        
	struct FString                                     AvatarPositionWidth_12_699EA5C07AF9251538B9AA9D0E76BAE8;   
	struct FString                                     AvatarPositionLong_13_2F4DC9C079A02A0560B7794104E7A257;    
	struct FString                                     LightLevelName_14_4980F50004BC70381F310B1E0DE28A45;        
	struct FString                                     SceneName_15_3B50D48067150C2E7CDC093801ABE845;             
	struct FString                                     LightLevelNameLow_16_42AEE18036CF9E14443D542508A45D47;     
};

}

