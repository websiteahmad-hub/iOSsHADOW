// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ReturnLoadingConfig_type
{
	int                                                caseID_0_482E54C04C3495DD3EF8909602BC5A04;                 
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     desc_1_786572405B57A2C12A0C693E03D28853;                   
	struct FString                                     imgPath_2_4FDAFD006287CA1826E00CC80E705588;                
	int                                                showCount_3_578E1D003D5589EC5486D01B0A8551E4;              
	int                                                slapID_4_0D16D9C0338F2A776C02D76D03C64704;                 
	struct FString                                     title_5_05F4930048F8C85629EE3A330D394715;                  
};

}

