// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCTemplateConfig_type
{
	int                                                ID_2_61A845005C2964C41597291409E48094;                     
	int                                                MapID_4_190D0C8075D155B82553779F08171A94;                  
	struct FString                                     Name_5_07B8C20059F6E9CC4AEA97D604810FD5;                   
	TArray<int>                                        ShowParams_a_6_5605B300124A7656312D1C800960C1B1;           
	TArray<int>                                        DefaultShortcutBarData_a_10_68B21DC07FF89BAF511A83F30F7FF501; 
	struct FString                                     Image_13_71629A80134150BA3A0ED6B2080CA995;                 
	int                                                MinPlayerNum_14_576A920029ACAE1411FB4EB5098BC61D;          
	int                                                IsNewbieGuide_15_5E4062C00FE56E9F34AAB0600B643A35;         
	int                                                SubModeID_16_07E490C0773386D96A4A4B61098DB7F4;             
	int                                                IsSkipDownload_17_2CE484804CB810DA44D9C6170763B084;        
};

}

