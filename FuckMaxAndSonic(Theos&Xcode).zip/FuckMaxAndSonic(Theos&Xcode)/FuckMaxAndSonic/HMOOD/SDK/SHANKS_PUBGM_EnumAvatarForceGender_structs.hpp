// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
enum class EnumAvatarForceGender : uint8_t
{
	EnumAvatarForceGender__NewEnumerator0 = 0,
	EnumAvatarForceGender__NewEnumerator1 = 1,
	EnumAvatarForceGender__NewEnumerator2 = 2,
	EnumAvatarForceGender__EnumAvatarForceGender_MAX = 3
};



}

