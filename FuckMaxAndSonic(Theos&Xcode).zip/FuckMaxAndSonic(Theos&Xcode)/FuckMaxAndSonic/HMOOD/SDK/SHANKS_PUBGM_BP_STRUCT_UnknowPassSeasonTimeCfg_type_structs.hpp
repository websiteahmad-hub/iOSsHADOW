// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UnknowPassSeasonTimeCfg_type
{
	int                                                MissionWeekCount_2_3CB96A402D71B7EF4EA765BA0A8008B4;       
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     SeasonName_4_198FC84010193A5D4BC03E0C0720EB85;             
	int                                                SeasonId_5_3B8D934038AA335B7B858D350DB71F54;               
	int                                                BuyPassItemId_6_30AE8E8065A87E267330F6C90EA73C94;          
	struct FString                                     ScoreRankEndTime_7_7EE3D94069FA9A2159155A850DBC7C95;       
	struct FString                                     SeasonStartTime_8_0E798F405F8F8D6164677B5B03E85045;        
	struct FString                                     DefaultWear_9_33A742C01852C10317B520BB0FF004F2;            
	struct FString                                     NormalOneTxt_11_4988E08017FE1CEC2DF6B76E0EE467C4;          
	struct FString                                     NormalTwoTxt_12_706186803DA56B081E42DD240C3E87C4;          
	struct FString                                     SuperOneTxt_13_7CCD8A0066CAA8FE1F94CE88049D0EC4;           
	struct FString                                     SuperTwoTxt_14_23A630006BDDA34C46A7D52D0265EEC4;           
	int                                                EliteItemId_15_11671980410B7BD4621304C80DC3F2A4;           
	int                                                NormalItemId_16_58673700213DA23423F9B9A10E8A8DC4;          
	struct FString                                     VersionStart_17_071E2AC00AF214F32E37281409C00E24;          
	int                                                CameraAction_18_45DCF78076C808C6211464D709D8AD8E;          
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     ResourseVerion_20_2E8400802432D43A7BFA747700751C7E;        
	struct FString                                     SeasonEndTime_21_55A2518052ACDA7E7AF9B3990292DFC5;         
	struct FString                                     RPScoreCoupon_24_1A96B24028A4D6594AA2C1EE0DBCB60E;         
	struct FString                                     DefaultExchangeWear_25_45D88B800748A1B609DDD66205CB3A12;   
	struct FString                                     DefaultSubwayWear_26_6F6B61804EEFBEA04A3200E0027EAF62;     
	int                                                EliteInvitationSkin_27_525D9900309AB4BC3FBB86AC0500751E;   
	int                                                PlusInvitationSkin_28_3DE3C54000C5C5E368AD3A0908F6D1EE;    
};

}

