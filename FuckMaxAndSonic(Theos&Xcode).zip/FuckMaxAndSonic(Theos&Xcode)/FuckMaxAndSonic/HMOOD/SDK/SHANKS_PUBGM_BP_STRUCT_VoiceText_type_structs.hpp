// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VoiceText_type
{
	int                                                VoiceTextId_0_6FC5DE403E05E86B27664BDF0A63A1A4;            
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     VoiceTextValue_1_0BE5D24055E8B9FB76C1783D0A09E585;         
};

}

