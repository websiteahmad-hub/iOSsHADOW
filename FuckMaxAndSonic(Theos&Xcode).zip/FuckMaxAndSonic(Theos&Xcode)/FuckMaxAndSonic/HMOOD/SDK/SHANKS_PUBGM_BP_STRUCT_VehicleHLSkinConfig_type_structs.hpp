// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehicleHLSkinConfig_type
{
	struct FString                                     ActorPath_0_6881F6C01796F0770103BED3085314F8;              
	int                                                CheckConfigId_1_18308D806C11E9D04D68837F085A5004;          
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     LevelSeq_2_6E94DD80624CAFC861DBC44F03195151;               
	int                                                SkinItemID_3_18AB81801A70E0582128A06D024C9FE4;             
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     Type_4_3A949DC006AA3E6F54547B1003461FB5;                   
	struct FString                                     UIPath_5_6B61E000223D6B823EC377DA0621BBE8;                 
	bool                                               PossessLobbyVehicle_6_6D903F402D19CF3B05493F59067CD905;    
};

}

