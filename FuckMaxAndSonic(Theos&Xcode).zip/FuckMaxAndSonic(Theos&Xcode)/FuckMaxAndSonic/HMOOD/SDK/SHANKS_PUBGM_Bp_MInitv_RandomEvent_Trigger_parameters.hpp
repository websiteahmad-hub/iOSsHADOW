// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct ABp_MInitv_RandomEvent_Trigger_C_UserConstructionScript_Params
{
};

}

