// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_WeaponScopeGlassMat_type
{
	struct FString                                     MaterialPath_0_5C2E3480396102E244C9A5850B9B5408;           
	struct FString                                     ScopeID_1_0872E740109AD1491DFC990E05CF6BF4;                
};

}

