// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UFireworksGatlinAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_103CE9D54941589FEC28F8A82AC2C65D_Params
{
};

 
struct UFireworksGatlinAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_7594665B453619945A04B9A45B53D8E5_Params
{
};

 
struct UFireworksGatlinAnimBP_C_EvaluateGraphExposedInputs_ExecuteUbergraph_FireworksGatlinAnimBP_AnimGraphNode_ModifyBone_76F3E93741D1EE0080E835BF9141B6D5_Params
{
};

 
struct UFireworksGatlinAnimBP_C_ExecuteUbergraph_FireworksGatlinAnimBP_Params
{
	int                                                EntryPoint;                                                
};

}

