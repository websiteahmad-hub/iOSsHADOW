// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct ABP_GameMode_MainCity_C_UserConstructionScript_Params
{
};

}

