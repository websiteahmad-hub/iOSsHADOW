// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_InGameAnimDataTable_type
{
	struct FString                                     DataAssetPath_0_7567ED4043E2B0F327760459069E5168;          
	int                                                ID_1_4C8A2EC037ED27350FAD135A0DD61684;                     
	int                                                Type_2_5C2554002D07C8607FED57B20617FDB5;                   
	struct FString                                     SharedIdGroupStr_3_20943E002C0AB39A2E94769F07C36102;       
};

}

