// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UBP_Phone_Anim_C_AnimNotify_ShowPhone_Params
{
};

 
struct UBP_Phone_Anim_C_ExecuteUbergraph_BP_Phone_Anim_Params
{
	int                                                EntryPoint;                                                
};

}

