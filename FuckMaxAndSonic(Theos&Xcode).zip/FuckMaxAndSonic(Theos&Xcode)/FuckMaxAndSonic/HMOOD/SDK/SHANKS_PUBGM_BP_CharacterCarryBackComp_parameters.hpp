// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UBP_CharacterCarryBackComp_C_FindFreedomLocationAndRotation_Params
{
	class ACharacter*                                  Character;                                                 
	bool                                               bValid;                                                    
	struct FVector                                     Location;                                                  
	struct FRotator                                    Rotation;                                                  
};

}

