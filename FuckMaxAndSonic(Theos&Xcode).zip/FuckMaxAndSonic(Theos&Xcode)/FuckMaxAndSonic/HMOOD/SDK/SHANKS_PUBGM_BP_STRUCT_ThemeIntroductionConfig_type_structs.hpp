// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ThemeIntroductionConfig_type
{
	struct FString                                     AchievementURL_0_26E6EF40794D16393C5ACAA408E1D18C;         
	struct FString                                     CollectionURL_2_08BF18000DD846BC73EA6012038FA9BC;          
	bool                                               IsOpen_3_5DE30BC0326092755C7F1EEF0816ED3E;                 
	unsigned char                                      UnknownData00[0x7];                                        
	struct FString                                     OfflineTime_5_7504ECC050CB40B1307EE09B08CE4BA5;            
	struct FString                                     OnlineTime_6_513F95406ACA2CF572B7054B05C2F995;             
	int                                                ThemeId_8_4CD8A0401E3E15877AE7E9580BC48194;                
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     PreheatingTime_10_70F7DDC03802D1AD369AA26C067992F5;        
	struct FString                                     TabTitle_11_465FFE801EE41CE015E5497A05F28D95;              
	struct FString                                     AlbumURL_12_41905140675CA2616152925C0011AD1C;              
	struct FString                                     ActivityURL_18_2BFCC8407BDF5A477585D1D7057D69DC;           
	int                                                CollectionID_20_789CFE800BEA4C560A4A6AE70D38FBE4;          
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     NewSessionEndTime_25_4CE9054015CE94B3642359DF00658E25;     
	struct FString                                     NewSessionStartTime_27_37748300436E03F43B3A8ADC04BBB2B5;   
	struct FString                                     OperationActivityURL_28_1B2A14802607FFF428C6DEB30F6F43FC;  
	struct FString                                     SwitchPreheatingTime_32_69861A40223497135D8B065908730D25;  
	struct FString                                     SwitchSessionTime_33_18CED180565F155C644264AD0FF66EB5;     
	int                                                AchievementViewID_34_0830FC800BB67AF453804AC50D7145C4;     
	unsigned char                                      UnknownData03[0x4];                                        
	struct FString                                     AchievementIDList_35_767C3CC004E8D85F4C9992460C67BEB4;     
	struct FString                                     ClientVersion_36_6FAE09801B81BEA8110CBF0005CE83BE;         
};

}

