// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_AvatarDefaultConfig_type
{
	int                                                id_0_582DD74020EEE8C12D00E1A40C84B664;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     pant_1_00F930C0654EFFCD6B08CAF404B7FCD4;                   
	struct FString                                     shirt_2_53D54E8062374FD817805CCA0B7038D4;                  
	struct FString                                     shoe_3_12522FC065073BE56B0E507104B703D5;                   
	TArray<int>                                        IngoreSlots_a_4_7117F240470C88771F536A8F0FB09CB1;          
};

}

