// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VoiceActorCfg_type
{
	int                                                ActorItemID_1_7EA64A805D4CF7C83F9ED7C20956DD34;            
	int                                                ActorID_2_66EEA6C00EC097255E83F50D0C7CE884;                
	struct FString                                     ActorName_5_084563C0289004B337AECB5D0CE91C45;              
	int                                                SortKey_9_023E1980778A370A5BD689D703B81F89;                
	int                                                IsUnLock_11_5BD327406959D86F0700649705BBD32B;              
	bool                                               IsPlayInGlobal_12_14DF9BC04FFBCB15583BB67E0769332C;        
	unsigned char                                      UnknownData00[0x7];                                        
	struct FString                                     OpenTime_15_14046D8013EB228646C4CC690BBB4AE5;              
	struct FString                                     BankDepend_16_1453384006553C13591DBA5107495114;            
	struct FString                                     BankName_17_72DF248073CEC0563E7F45210B58A305;              
	bool                                               IsLimitRegion_19_4FEB4D00214E87C4181FAD020238523E;         
	bool                                               IsShowUntilGet_20_24C807804D192C0A34758E20002987D4;        
	unsigned char                                      UnknownData01[0x6];                                        
	struct FString                                     OpenPublish_21_4EEE3F807004AA067FA56CB009D6AB28;           
	struct FString                                     OpenRegion_22_25FEC2C01D13489B7B49BCAA0B6D05EE;            
	int                                                ActorQuality_23_309BFDC07AD15BDF4630985F0D71FE29;          
	int                                                IsMultiLanguage_24_68B560007D614E8A22F1FC6B03037045;       
	bool                                               IsWardrobeHidden_25_55BBB4C002A2206144511CB70982EAFE;      
	unsigned char                                      UnknownData02[0x7];                                        
	struct FString                                     MultiLanguageActorIDList_26_10829980195F82E04E49A4FC0FDD54F4; 
	int                                                SortKeyJP_27_276D80003AE6692C369ECA2A081F8E40;             
	int                                                SortKeyKR_28_567460C05940793D369EF038081F8FB2;             
	bool                                               IsContainingSign_29_4B537B000BD895EA3459001502F0590E;      
	unsigned char                                      UnknownData03[0x3];                                        
	int                                                OpenTimestamp_30_3CD156C01C22BF6B71400E1D0E7114E0;         
};

}

