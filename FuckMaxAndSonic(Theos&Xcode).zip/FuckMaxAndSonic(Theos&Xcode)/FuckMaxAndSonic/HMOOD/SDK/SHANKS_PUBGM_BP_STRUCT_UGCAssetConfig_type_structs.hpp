// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCAssetConfig_type
{
	int                                                AssetID_0_6C1CB6005152E2225E501F6100A93244;                
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Desc_1_4A0392802C18CB063DA2123E0FA92C93;                   
	int                                                ID_4_5F44160067247D64681C18D9000FA954;                     
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     Name_5_03E393000E13964C3DBD91440FAAC835;                   
	TArray<int>                                        ResArray_a_6_4341AD00601787C843D1519007308321;             
	int                                                ResSeprateType_7_1E557AC007537C097EC0E2E7042CEFE5;         
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     HDIcon_8_674B1800689BD6DA2E2595D20948F7FE;                 
	struct FString                                     Icon_9_37F8B50009EF18043DB023720FA97A5E;                   
	int                                                DeviceType_11_0A546F401898C3D950674F5B0033ACA5;            
	int                                                SortWeight_12_7D47F6C00275F1AF0A31276A0673DB64;            
	int                                                TabID_14_3C985BC06772649D7ABBFE950A827624;                 
	unsigned char                                      UnknownData03[0x4];                                        
	TArray<int>                                        Tags_a_15_3AC9E68016D9AB7C6FD004200827E8F1;                
	struct FString                                     DependResType_17_1FAC59C0589C6DFB6C7642860A0EFE65;         
	int                                                IsSingleMeshAsset_19_32F9BD8073D966146D8741B807428314;     
	unsigned char                                      UnknownData04[0x4];                                        
	TArray<struct FString>                             DependFeatures_as_20_102F03401139C6AD0AFFB8C602930B63;     
};

}

