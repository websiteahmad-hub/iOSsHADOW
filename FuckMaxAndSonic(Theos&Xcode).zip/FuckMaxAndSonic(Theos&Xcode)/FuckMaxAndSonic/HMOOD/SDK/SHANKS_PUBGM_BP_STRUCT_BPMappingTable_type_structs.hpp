// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_BPMappingTable_type
{
	struct FString                                     BPMapping_0_359D8E805EAA95B608F926810D8E6097;              
	int                                                ItemID_2_53343E0047BD3A720C3CF0DE04726144;                 
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     DependPath_3_269ACE405F922C993E0095690CDABC28;             
	struct FString                                     ActorMapping_4_57DC08407CB974393F1F63C300853947;           
};

}

