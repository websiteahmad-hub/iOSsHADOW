// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ColorBlindnessConfig_type
{
	struct FString                                     CBBlueColorA_19_362F368060B105F828F4BADE0EAF4721;          
	struct FString                                     CBBlueColorB_27_363036C060B105F928F4BADF0EAF4722;          
	struct FString                                     CBBlueColorG_29_3635380060B105FE28F4BAA40EAF4727;          
	struct FString                                     CBBlueColorR_23_36403AC060B1060928F4BAAF0EAF4732;          
	struct FString                                     CBGreenColorA_17_5F0D90C03949D01D2EBEC7C9023492B1;         
	struct FString                                     CBGreenColorB_28_5F0E91003949D01E2EBEC7CE023492B2;         
	struct FString                                     CBGreenColorG_32_5F1392403949D0232EBEC7C3023492B7;         
	struct FString                                     CBGreenColorR_25_5F1E95003949D02E2EBEC7DE023492A2;         
	struct FString                                     CBRedColorA_18_12FF5B40473229556BCC523607F696F1;           
	struct FString                                     CBRedColorB_26_13005B80473229566BCC522907F696F2;           
	struct FString                                     CBRedColorG_30_13055CC04732295B6BCC522C07F696F7;           
	struct FString                                     CBRedColorR_24_13105F80473229666BCC521907F696E2;           
	struct FString                                     ID_35_5A5046801FF3596E474DD8DF0D82F7A4;                    
	struct FString                                     NormalColorA_31_0DCD2D8036DBB8744E67B41408EF47F1;          
	struct FString                                     NormalColorB_22_0DCE2DC036DBB8754E67B41508EF47F2;          
	struct FString                                     NormalColorG_21_0DD32F0036DBB87A4E67B41E08EF47F7;          
	struct FString                                     NormalColorR_20_0DDE31C036DBB8854E67B42508EF47E2;          
};

}

