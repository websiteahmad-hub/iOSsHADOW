// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_Client120FPSExpandMapping_type
{
	int                                                ID_0_43452A8067B55B5E0CB38F2B00D093B4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     MaxFPSByQuality_1_2958F40001887B921A3E5A4F090C2CD9;        
	struct FString                                     ModelNames_2_784A808077F4CA90549441AA0CA026B3;             
	struct FString                                     RecommendFPS_3_58A368001D690F9C2374E792016FDDE3;           
};

}

