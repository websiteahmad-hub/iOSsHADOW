// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_SeasonVersion_type
{
	int                                                SeasonID_1_37EED6C0265C64EB753705C10E9C1764;               
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     MinVersion_2_631EDBC03A79884B4EECE45E0E9C857E;             
	struct FString                                     MaxVersion_3_44581C4049916A796DCF1E470E9C839E;             
	struct FString                                     SeasonStartBPpath_4_238D26C06BD735631644A269091629F8;      
	struct FString                                     SeasonStartLuaPath_6_267862C03D0622FF3BAF7EEE05A27D08;     
	struct FString                                     SeasonStartOrder_7_443BB6005B469ABE29ED099505A09ED2;       
};

}

