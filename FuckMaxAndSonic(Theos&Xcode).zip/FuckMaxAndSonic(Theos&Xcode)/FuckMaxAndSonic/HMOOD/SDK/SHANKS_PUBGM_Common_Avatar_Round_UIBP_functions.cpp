// HMOOD__TG@i_8_f
 

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
 
 
 

void UCommon_Avatar_Round_UIBP_C::PreConstruct(bool* IsDesignTime)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_Avatar_Round_UIBP.Common_Avatar_Round_UIBP_C.PreConstruct");

	UCommon_Avatar_Round_UIBP_C_PreConstruct_Params params;
	params.IsDesignTime = IsDesignTime;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 

void UCommon_Avatar_Round_UIBP_C::ExecuteUbergraph_Common_Avatar_Round_UIBP(int EntryPoint)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function Common_Avatar_Round_UIBP.Common_Avatar_Round_UIBP_C.ExecuteUbergraph_Common_Avatar_Round_UIBP");

	UCommon_Avatar_Round_UIBP_C_ExecuteUbergraph_Common_Avatar_Round_UIBP_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = pFunc->FunctionFlags;

	UObject *currentObj = (UObject *) this;
	currentObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


}

