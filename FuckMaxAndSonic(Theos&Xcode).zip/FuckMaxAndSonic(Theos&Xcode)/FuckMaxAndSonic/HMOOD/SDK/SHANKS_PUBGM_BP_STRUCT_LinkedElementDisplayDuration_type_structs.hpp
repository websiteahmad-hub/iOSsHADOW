// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_LinkedElementDisplayDuration_type
{
	struct FString                                     EndTime_0_3E909E4074F1ED5543BC580D0052A7C5;                
	struct FString                                     MaxVersion_1_1A2537C031A5AC7F0A81B8C60C56E73E;             
	struct FString                                     MinVersion_2_38EBF74041A9E16D102E06DC0C56E1DE;             
	int                                                OpenId_3_23E5E4806398882E0C32B3190F271264;                 
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     StartTime_4_66E31C00167F804E2DBAB27803905285;              
	struct FString                                     MapList_5_5C3703404E8DEC314AC876C807A03954;                
	struct FString                                     SubMod_6_7ABC874066CFFE273FA249C90FEAE4C4;                 
};

}

