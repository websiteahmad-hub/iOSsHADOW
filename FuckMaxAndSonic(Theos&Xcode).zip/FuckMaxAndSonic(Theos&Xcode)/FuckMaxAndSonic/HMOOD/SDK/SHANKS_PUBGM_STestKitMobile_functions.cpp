// HMOOD__TG@i_8_f
 

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
 
 
 
 
 

bool USTestKitMobileLibrary::TapWidget(class UWidget* Widget, const struct FSTestMobileTapOptions& Options)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.TapWidget");

	USTestKitMobileLibrary_TapWidget_Params params;
	params.Widget = Widget;
	params.Options = Options;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

bool USTestKitMobileLibrary::ShowConnectionPanel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.ShowConnectionPanel");

	USTestKitMobileLibrary_ShowConnectionPanel_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

bool USTestKitMobileLibrary::RequestPairing()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.RequestPairing");

	USTestKitMobileLibrary_RequestPairing_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 
 
 

bool USTestKitMobileLibrary::ReportResult(const struct FString& RunId, bool bSuccess, const struct FString& Payload, const struct FString& Error)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.ReportResult");

	USTestKitMobileLibrary_ReportResult_Params params;
	params.RunId = RunId;
	params.bSuccess = bSuccess;
	params.Payload = Payload;
	params.Error = Error;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 

bool USTestKitMobileLibrary::ReportEvent(const struct FString& RunId, const struct FString& EventJson)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.ReportEvent");

	USTestKitMobileLibrary_ReportEvent_Params params;
	params.RunId = RunId;
	params.EventJson = EventJson;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

bool USTestKitMobileLibrary::IsRuntimeEnabled()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.IsRuntimeEnabled");

	USTestKitMobileLibrary_IsRuntimeEnabled_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

bool USTestKitMobileLibrary::IsBridgeConnected()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.IsBridgeConnected");

	USTestKitMobileLibrary_IsBridgeConnected_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 

bool USTestKitMobileLibrary::HitTestSelf(class UWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.HitTestSelf");

	USTestKitMobileLibrary_HitTestSelf_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 

void USTestKitMobileLibrary::HideConnectionPanel()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.HideConnectionPanel");

	USTestKitMobileLibrary_HideConnectionPanel_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 

struct FVector4 USTestKitMobileLibrary::GetWidgetRect(class UWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.GetWidgetRect");

	USTestKitMobileLibrary_GetWidgetRect_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

struct FString USTestKitMobileLibrary::GetUIReferenceCaptureStatusJson()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.GetUIReferenceCaptureStatusJson");

	USTestKitMobileLibrary_GetUIReferenceCaptureStatusJson_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 

struct FVector2D USTestKitMobileLibrary::GetScreenCenter(class UWidget* Widget)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.GetScreenCenter");

	USTestKitMobileLibrary_GetScreenCenter_Params params;
	params.Widget = Widget;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

struct FString USTestKitMobileLibrary::GetPairingCode()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.GetPairingCode");

	USTestKitMobileLibrary_GetPairingCode_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

struct FString USTestKitMobileLibrary::GetDeviceId()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.GetDeviceId");

	USTestKitMobileLibrary_GetDeviceId_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 

struct FString USTestKitMobileLibrary::GetBridgeStatusJson()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.GetBridgeStatusJson");

	USTestKitMobileLibrary_GetBridgeStatusJson_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 
 

class UWidget* USTestKitMobileLibrary::FindWidgetInUI(const struct FString& UIName, const struct FString& WidgetName, int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.FindWidgetInUI");

	USTestKitMobileLibrary_FindWidgetInUI_Params params;
	params.UIName = UIName;
	params.WidgetName = WidgetName;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 

class UWidget* USTestKitMobileLibrary::FindUserWidgetByUIName(const struct FString& UIName, int Index)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.FindUserWidgetByUIName");

	USTestKitMobileLibrary_FindUserWidgetByUIName_Params params;
	params.UIName = UIName;
	params.Index = Index;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 
 

bool USTestKitMobileLibrary::FillText(class UWidget* Widget, const struct FString& Text, const struct FSTestMobileFillOptions& Options)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.FillText");

	USTestKitMobileLibrary_FillText_Params params;
	params.Widget = Widget;
	params.Text = Text;
	params.Options = Options;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 

struct FString USTestKitMobileLibrary::DumpRuntimeWidgetTree(bool bVisibleOnly, bool bIncludeText)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.DumpRuntimeWidgetTree");

	USTestKitMobileLibrary_DumpRuntimeWidgetTree_Params params;
	params.bVisibleOnly = bVisibleOnly;
	params.bIncludeText = bIncludeText;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 
 

bool USTestKitMobileLibrary::DragWidget(class UWidget* From, class UWidget* To, const struct FSTestMobileDragOptions& Options)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.DragWidget");

	USTestKitMobileLibrary_DragWidget_Params params;
	params.From = From;
	params.To = To;
	params.Options = Options;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 
 
 

bool USTestKitMobileLibrary::DragByOffset(class UWidget* Widget, float Dx, float Dy, const struct FSTestMobileDragOptions& Options)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.DragByOffset");

	USTestKitMobileLibrary_DragByOffset_Params params;
	params.Widget = Widget;
	params.Dx = Dx;
	params.Dy = Dy;
	params.Options = Options;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 

void USTestKitMobileLibrary::DisconnectBridge()
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.DisconnectBridge");

	USTestKitMobileLibrary_DisconnectBridge_Params params;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;
}


 
 
 
 
 
 

bool USTestKitMobileLibrary::ConnectBridge(const struct FString& BridgeUrl, bool bSaveUrl)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.ConnectBridge");

	USTestKitMobileLibrary_ConnectBridge_Params params;
	params.BridgeUrl = BridgeUrl;
	params.bSaveUrl = bSaveUrl;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 

struct FString USTestKitMobileLibrary::CollectVisibleWidgetBlueprintPaths(int MaxDepth)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.CollectVisibleWidgetBlueprintPaths");

	USTestKitMobileLibrary_CollectVisibleWidgetBlueprintPaths_Params params;
	params.MaxDepth = MaxDepth;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 

struct FString USTestKitMobileLibrary::CollectVisibleWidgetBlueprintHierarchy(int MaxDepth)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.CollectVisibleWidgetBlueprintHierarchy");

	USTestKitMobileLibrary_CollectVisibleWidgetBlueprintHierarchy_Params params;
	params.MaxDepth = MaxDepth;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 
 
 

bool USTestKitMobileLibrary::CaptureAndUploadUIReference(const struct FString& ServerURL, const struct FString& APIKey, const struct FString& Source, int JpegQuality)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.CaptureAndUploadUIReference");

	USTestKitMobileLibrary_CaptureAndUploadUIReference_Params params;
	params.ServerURL = ServerURL;
	params.APIKey = APIKey;
	params.Source = Source;
	params.JpegQuality = JpegQuality;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


 
 
 
 
 
 

bool USTestKitMobileLibrary::CaptureAndUploadConfiguredUIReference(const struct FString& Source, int JpegQuality)
{
	static UFunction *pFunc = 0;
	if (!pFunc)
		pFunc  = UObject::FindObject<UFunction>("Function STestKitMobile.STestKitMobileLibrary.CaptureAndUploadConfiguredUIReference");

	USTestKitMobileLibrary_CaptureAndUploadConfiguredUIReference_Params params;
	params.Source = Source;
	params.JpegQuality = JpegQuality;

	auto flags = pFunc->FunctionFlags;
	pFunc->FunctionFlags |= 0x400;

	static auto defaultObj = StaticClass()->GetDefaultObject();
	defaultObj->ProcessEvent(pFunc, &params);

	pFunc->FunctionFlags = flags;

	return params.ReturnValue;
}


}

