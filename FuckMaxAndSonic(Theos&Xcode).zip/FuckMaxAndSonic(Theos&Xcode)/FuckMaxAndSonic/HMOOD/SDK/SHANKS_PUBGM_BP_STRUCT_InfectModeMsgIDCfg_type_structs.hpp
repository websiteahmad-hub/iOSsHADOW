// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_InfectModeMsgIDCfg_type
{
	int                                                FlagType_0_72B3F500739E321A0A23CC9D077EF635;               
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     TurnplateChatIDList_1_096F880020F397FC54CCF31403E9DA74;    
	struct FString                                     MenuChatIDList_2_3D047D80224763B807E924800784F994;         
};

}

