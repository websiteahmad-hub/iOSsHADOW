// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UObject_ExecuteUbergraph_Params
{
	int                                                EntryPoint;                                                
};

}

