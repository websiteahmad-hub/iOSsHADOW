// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_AvatarWeaponHitFXData_type
{
	struct FString                                     EffectPath_0_10BE9D8007788EA45AF4C54C06DC3028;             
	int                                                ID_1_5D54EA4001CDCE7777865F5B044D7534;                     
};

}

