// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FTemBPDataAddr
{
	uint64_t                                           Value;                                                     
	unsigned char                                      UnknownData00[0x10];                                       
};

}

