// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_EffectItemBPTable_type
{
	struct FString                                     CName_0_7A84EC0050230586473C7F7D0FE10665;                  
	int                                                ID_1_77819E4026AAFDFB236ABAEE0425FEA4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     LobbyPath_2_667FDC4028D32C79798D4B120AC19EB8;              
	struct FString                                     Path_3_084F3E402A58FF7D0D305BF205FF1C88;                   
};

}

