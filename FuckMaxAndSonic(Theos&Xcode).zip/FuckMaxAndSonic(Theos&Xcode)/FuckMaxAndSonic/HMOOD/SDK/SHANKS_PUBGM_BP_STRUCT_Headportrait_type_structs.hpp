// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_Headportrait_type
{
	struct FString                                     Desc_0_400BFEE6409617111ABD269F7FF07B5B;                   
	int                                                Quality_1_67881EA24F1E186A2AF389BBB7C62995;                
	int                                                ID_4_E5F66BB44E8FF9988F28C38D370137DF;                     
	int                                                UnlockType_5_FA4BE0754F644CE090DF7388DEBEFF9F;             
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     UnlockDesc_6_1033BFE2476FB300BD448E86EEC3F4C7;             
	int                                                UnlockParam_7_550F64A04DD9EAED9924FF98E01B12EB;            
	bool                                               isShow_8_E33D5FA9430ABBA58D44C881AECC498E;                 
	unsigned char                                      UnknownData01[0x3];                                        
	struct FString                                     Name_9_F16C3B4F4884A591B5397DA34A668E9D;                   
	int                                                DefaultDisplay_10_4C6C4600503520F476BB02F609D7B029;        
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     ShowTime_11_59E76B406521918521EF4BAE0879B025;              
	struct FString                                     JumpUrl_12_1EA4330028ACEF420C12695609350CAC;               
	struct FString                                     DynamicIcon_13_3DAAD2C042DD4FDB2321F49103E48D6E;           
	struct FString                                     DynamicIconBig_14_7A4B57403D3E961F79C0C0D408D716B7;        
};

}

