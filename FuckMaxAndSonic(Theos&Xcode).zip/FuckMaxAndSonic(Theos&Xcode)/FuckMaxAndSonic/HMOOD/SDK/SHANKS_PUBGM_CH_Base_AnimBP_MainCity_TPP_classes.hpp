// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
class UCH_Base_AnimBP_MainCity_TPP_C : public UCharMainMCAnimInstance
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            
	struct FAnimNode_Slot                              AnimGraphNode_Slot_95EC37444D2783028D0509B3D2BC31DA;       
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_33BBAA8F44ABFE1314FE938843BD045F; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_61316C7E46619171838C3F963F405D2A; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_76B99DC84072BA3C0786C29E9E29BB65; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_4B9202814EAEE5E8C6F84BBCA2B779F3; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_895296D24A9F7A856166378E952F6B69; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A1EFD8F1495CE7BAD195DDB44A756B68; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_FE062345416B64A640EA20B26FCCADD2; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_1CA6B8D5497E74E6F43CAEB6DDEFBBC5; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_1873132544FC0C24E6E9D78009A10781; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_9E88F58F4AB6EE52BA9A69BFC886550A; 
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_848561B04A016AA68BCBBE8EFFA343FD; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_4F9BC4314BE4DA84F20AD4A27AAC395A; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_FFF262E84F13F43A0FDF44A2F37CA696; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_9D9D8FCC441A7F05532D81BE6C797E4A; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_5DD0B0D24ED85ACF9D4CB39EE7DC6F51; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6E1D113D4A61E2CDD8D86989D7072B12; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_06F8D9E54D6A670C97160781AAC21798; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_A5BBC01C4E35430A5EA3F7B595589567; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_4F5E39D64276B82ED0F85587898EA736; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_1CF150234CC2C8D35D381F9C7E447C27; 
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_EC58EF22440F5629E656CCACAAC6425B; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_C489CE0542F69637F4FF2A8E70E7FF28; 
	struct FAnimNode_ApplyAdditive                     AnimGraphNode_ApplyAdditive_6BCD08EB410E000767F30D81197CD228; 
	struct FAnimNode_RotateRootBone                    AnimGraphNode_RotateRootBone_3379463249DB5026719BCDA500803EDE; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_B02F45DC49034869CCF72E8A45EDDEDA; 
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_B67104D44ACE002A28E6C59C9001EE5A; 
	struct FAnimNode_Slot                              AnimGraphNode_Slot_4EC4E5F3433702D6A993089DD613B5AA;       
	struct FAnimNode_LayeredBoneBlend                  AnimGraphNode_LayeredBoneBlend_B8BB26944D9EAC6456923CB5DA53168E; 
	struct FAnimNode_Slot                              AnimGraphNode_Slot_1C9142144003EF79A3FF3882AC6BD71A;       
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_09469ACD4053F9462C5C3FA079746818; 
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_0EDC83854E6532859A698DA8FAA223B3; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_B26849D94D98F246150DB3B5254FFE0F; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_0E7FDF5D4A5B2417CBCFD0A80DF3AE8B; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_125A562843C0C4FBD9B9DAAFAB82F834; 
	struct FAnimNode_SaveCachedPose                    AnimGraphNode_SaveCachedPose_835206744B1115E35B53278B35ABBBF0; 
	struct FAnimNode_Slot                              AnimGraphNode_Slot_DB6B3DFA4FD15B2604FE679CDAB849F9;       
	struct FAnimNode_BlendListByEnumAdvance            AnimGraphNode_BlendListByEnumAdvance_2F85DDD4439D6AC83CDEFCAA8ADCC6E0; 
	struct FAnimNode_Slot                              AnimGraphNode_Slot_89E0DE5E46485E04CDF60A9F236DA1F9;       
	struct FAnimNode_ConvertLocalToComponentSpace      AnimGraphNode_LocalToComponentSpace_26A9200640DB38F809204BAF119687E3; 
	struct FAnimNode_ConvertComponentToLocalSpace      AnimGraphNode_ComponentToLocalSpace_311D18DF4EEC152C513A66BFF2CA60C3; 
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_71DA3A28400B4A1791A9BBBBFB374409; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_C6EC376C47FC1946B476B89CFD7AE2E2; 
	struct FAnimNode_AnimInstanceContainer             AnimGraphNode_AnimInstanceContainer_58BEE2C343A11CD805F0CEAEB2669FDE; 
	struct FAnimNode_Root                              AnimGraphNode_Root_F17603FF4C45548C8ECEEB9825890D0C;       
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_9C7680144809F374A3ECDEB605A6DFA5; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_276B8A6E4849011CC43D74BE513D5D67; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_0711472B4AB410F69CEB17B8D446FE84; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_52B6FA714412F66DBF7662B5B3C9F68D; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_CA34E19646F8F7246E801490D9A50514; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_773C778646FD5FE40EAA4F9EF41163ED; 
	struct FAnimNode_AnimInstanceContainer             AnimGraphNode_AnimInstanceContainer_28A00FFE4AD18CFA8F7A4EABD34054C3; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6BF56DAA497D92AB3AB118BCB03FE51A; 
	struct FAnimNode_UseCachedPose                     AnimGraphNode_UseCachedPose_13317A20404CC7DB24D990BC785C1594; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_663C7ED241FE57E0B0C2549F38609B04; 
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_6BDF46C2426A99A12D87ADA623923289; 
	struct FAnimNode_Slot                              AnimGraphNode_Slot_4DFF26E94B946D1CC43CB3ADBCBC5195;       
	struct FAnimNode_Slot                              AnimGraphNode_Slot_F2B40EF4412D46DA0EE231B0B9A13F0A;       
	struct FAnimContainer                              MotionOverLayer;                                           

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass CH_Base_AnimBP_MainCity_TPP.CH_Base_AnimBP_MainCity_TPP_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_06F8D9E54D6A670C97160781AAC21798();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_9E88F58F4AB6EE52BA9A69BFC886550A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendListByBool_EC58EF22440F5629E656CCACAAC6425B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_C489CE0542F69637F4FF2A8E70E7FF28();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_ApplyAdditive_6BCD08EB410E000767F30D81197CD228();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_RotateRootBone_3379463249DB5026719BCDA500803EDE();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_1873132544FC0C24E6E9D78009A10781();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendListByBool_09469ACD4053F9462C5C3FA079746818();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendListByEnumAdvance_2F85DDD4439D6AC83CDEFCAA8ADCC6E0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_AnimInstanceContainer_58BEE2C343A11CD805F0CEAEB2669FDE();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_9C7680144809F374A3ECDEB605A6DFA5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_276B8A6E4849011CC43D74BE513D5D67();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_1CA6B8D5497E74E6F43CAEB6DDEFBBC5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_0711472B4AB410F69CEB17B8D446FE84();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_52B6FA714412F66DBF7662B5B3C9F68D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_FE062345416B64A640EA20B26FCCADD2();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_AnimInstanceContainer_28A00FFE4AD18CFA8F7A4EABD34054C3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_A1EFD8F1495CE7BAD195DDB44A756B68();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_895296D24A9F7A856166378E952F6B69();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_BlendSpacePlayer_848561B04A016AA68BCBBE8EFFA343FD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_4B9202814EAEE5E8C6F84BBCA2B779F3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_5DD0B0D24ED85ACF9D4CB39EE7DC6F51();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_76B99DC84072BA3C0786C29E9E29BB65();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_SequencePlayer_FFF262E84F13F43A0FDF44A2F37CA696();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP_AnimGraphNode_TransitionResult_61316C7E46619171838C3F963F405D2A();
	void AnimNotify_PlayFallSound();
	void AnimNotify_SpawnLFootprint();
	void AnimNotify_SpawnRFootprint();
	void ExecuteUbergraph_CH_Base_AnimBP_MainCity_TPP(int EntryPoint);
};


}

