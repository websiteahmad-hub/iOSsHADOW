// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_WeaponReuseCfgTable_type
{
	int                                                ReuseAttachMeshID_0_5434FBC01C8BEB516724520609513054;      
	int                                                ReuseAvatarID_1_4546FB007C83124E1571E69B0A8192B4;          
	int                                                ReuseDefaultAttachID_2_7C7649C07EECDDC5161C8EEB079CE084;   
	int                                                ReuseFovID_3_4A896E0025C515CC35B3061B01430A64;             
	int                                                ReuseSupportAttachID_4_52FB37C0468A0A5532B875EE0C4070F4;   
	int                                                ReuseSupportBulletID_5_2F445C800F9CE3205C956C620DD524E4;   
	int                                                WeaponBPID_6_133CA14062C42FFD677CE3FD0F9C4324;             
	int                                                WeaponID_7_4308BCC073680B1B09069F6E07FF9CE4;               
	int                                                SensibilitySettingID_8_3ADF9D80659D80D4403A7C5600868484;   
	int                                                ReuseDefaultAttachAvatar_9_0FC3BE4007A769455278A94600DB1662; 
};

}

