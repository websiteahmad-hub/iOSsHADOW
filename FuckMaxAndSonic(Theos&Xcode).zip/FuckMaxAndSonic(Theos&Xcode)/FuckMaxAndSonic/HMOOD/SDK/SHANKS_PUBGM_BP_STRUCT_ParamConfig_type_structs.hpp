// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ParamConfig_type
{
	struct FString                                     ParamName_0_3E5093C0622417BF51FDE5CD07CE52A5;              
	int                                                ParamValue_1_11E112C00B831E5D3BCE331C0CED2AC5;             
};

}

