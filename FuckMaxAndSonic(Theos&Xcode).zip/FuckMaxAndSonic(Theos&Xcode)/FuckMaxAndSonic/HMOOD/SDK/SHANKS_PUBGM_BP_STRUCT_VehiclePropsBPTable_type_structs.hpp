// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehiclePropsBPTable_type
{
	struct FString                                     Path_0_4EDAFC402F5F7A8148151E1F0E26A1A8;                   
	int                                                ID_1_788B5C402A5D724740AE2C51090E2714;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     CName_2_3B11AA00669A1BB25698D87D027CD8D5;                  
};

}

