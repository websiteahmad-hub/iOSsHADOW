// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_ugc_review_panel_season_table_type
{
	struct FString                                     begin_time_0_0897A5C03C3A702968957BC60CADF645;             
	struct FString                                     end_time_1_1441F2401F0B0EED52D817E005420545;               
	struct FString                                     open_version_2_126366C07F03837F56A202D2007EB89E;           
	int                                                season_id_3_6A782E40466FCD6D7E9B94E502F0A154;              
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     season_name_4_3BFF634042099DAB063605F800A2E6C5;            
};

}

