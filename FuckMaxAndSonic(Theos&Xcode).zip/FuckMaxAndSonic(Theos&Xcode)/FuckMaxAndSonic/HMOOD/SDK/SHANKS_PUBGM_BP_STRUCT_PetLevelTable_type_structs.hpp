// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_PetLevelTable_type
{
	int                                                ActionID1_0_54564EC00C46D1792A24097D014062A1;              
	int                                                KeyID_1_38C8754040A625D32E969D6F0A59B604;                  
	int                                                ActionID2_2_54574F000C46D17A2A24097C014062A2;              
	int                                                PetLevel_3_0EFEB00033E6898053D6CAD40B4F695C;               
	int                                                ActionCnt_4_6ED1A8806F6E05482A2429B001406784;              
	int                                                PetID_5_0C7F3540138C63E52ED3D2E20A5EB304;                  
	int                                                ActionID5_6_545A4FC00C46D17D2A240979014062A5;              
	int                                                ActionID4_7_54594F800C46D17C2A24097A014062A4;              
	int                                                ActionID3_8_54584F400C46D17B2A24097B014062A3;              
	int                                                PetNeedExp_9_5C9DFC4020A68805594D9EAF091E67B0;             
	struct FString                                     PetCharacter_10_0EB0D54006ABD083521623E20D6C9E82;          
	struct FString                                     AllAction_11_64FEE580365AA5C6529430360BA1003E;             
	struct FString                                     LobbyPetBP_12_6856D48026D8CEBA5718878204437A40;            
	struct FString                                     PetFPPCharacter_13_2475CEC05F8CAFC156D174270BE8BD92;       
	struct FString                                     PetLevelRewards_15_5109E60006928866497DD8620C3B1E13;       
};

}

