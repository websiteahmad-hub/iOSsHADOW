// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UBP_SwimController_C_EnterWater_BluePrint_Params
{
};

 
struct UBP_SwimController_C_BP_UnderWaterStateChanged_Params
{
	bool*                                              bEnterWater;                                               
};

 
struct UBP_SwimController_C_ExecuteUbergraph_BP_SwimController_Params
{
	int                                                EntryPoint;                                                
};

}

