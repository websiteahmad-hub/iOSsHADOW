// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCTemplateDataConfig_type
{
	int                                                ID_0_688CE38031D345FC3B33CE7B01656C34;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     InitialBin_1_3D1499004D869B9C63F717C40F9C2E9E;             
	struct FString                                     InitialMeta_2_320E5480041F47E6744693E809C35A51;            
};

}

