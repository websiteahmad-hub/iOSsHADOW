// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
#include "../SDK.hpp"

namespace SDK
{
 
 
 

 
struct UPetSpecifiedAnim_C_ReceiveExecuteAI_Params
{
	class AAIController**                              OwnerController;                                           
	class APawn**                                      ControlledPawn;                                            
};

 
struct UPetSpecifiedAnim_C_ExecuteUbergraph_PetSpecifiedAnim_Params
{
	int                                                EntryPoint;                                                
};

}

