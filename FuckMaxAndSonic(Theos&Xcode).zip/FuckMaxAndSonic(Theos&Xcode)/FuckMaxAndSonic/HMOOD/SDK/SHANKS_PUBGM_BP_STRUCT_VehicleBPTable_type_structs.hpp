// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_VehicleBPTable_type
{
	int                                                ID_0_0D9DF74051BBD583279703B701F172E4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Path_2_2F72974026FE3BC32110651501735958;                   
	struct FString                                     CName_3_138BC5001BE2FE5E5E66B36807255925;                  
	int                                                VehicleShapeID_4_2C43E38070C85DC025E56CC303F69884;         
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     LobbyPath_5_4594B5404A7DACE145FA22A607895AE8;              
};

}

