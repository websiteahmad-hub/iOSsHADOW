// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCModCollection_type
{
	struct FString                                     Desc_0_292848000B65189C739C1FEB0474CA93;                   
	int                                                ID_1_628E4B8056CA7ADE0C794F2B060474B4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Name_5_6308488003787CA27381BB4004752235;                   
	int                                                Sort_4_19B95240385E221B714B7EB004760094;                   
	int                                                RankTab_6_38EAF1002F42126C5547352B0E254D22;                
};

}

