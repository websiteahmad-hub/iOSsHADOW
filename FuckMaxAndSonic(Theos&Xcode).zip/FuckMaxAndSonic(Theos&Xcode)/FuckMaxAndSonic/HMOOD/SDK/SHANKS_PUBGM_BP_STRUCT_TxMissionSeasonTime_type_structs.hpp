// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_TxMissionSeasonTime_type
{
	struct FString                                     EndTime_0_345DF8807BA15BAE7D550BB20A24DA75;                
	int                                                ID_1_135AB2403279F84B5C84A49506D764F4;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Name_2_66F5EF40675A146D77DF7EE3076562E5;                   
	struct FString                                     StartTime_3_042E364021EF58D13D515C5105EFF8F5;              
	struct FString                                     EndTips_4_417A9CC0390F06097D55087A0A24E633;                
	int                                                IsDoubleExp_5_268D60007742E4F6565719B90DE084E0;            
	unsigned char                                      UnknownData01[0x4];                                        
	struct FString                                     RewardIDs_6_2DCA88405DE2375912CB4F5000FED713;              
	int                                                LocalID_7_76696D00317E8DFA4B4597EE01341684;                
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     SouvenirsSeasonIconGrey_8_07C384C05358D9E55E1F21320E043319; 
	struct FString                                     SouvenirsSeasonIconNormal_9_13D419402F4CE1A544C5ACAF05AD6D7C; 
	struct FString                                     MatchStartTime_10_0DC3518018C8605648119F2006E71185;        
	struct FString                                     SouvenirsSeasonIconShare_11_7C94DBC07CDB126D3013D3D300545565; 
	int                                                IsDoublePrestige_12_0C558580333BD76064D15FA40914A425;      
};

}

