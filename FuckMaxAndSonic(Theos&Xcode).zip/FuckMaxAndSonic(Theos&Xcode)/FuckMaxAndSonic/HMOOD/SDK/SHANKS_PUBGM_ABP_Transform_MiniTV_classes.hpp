// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
class UABP_Transform_MiniTV_C : public UPetTransformAnimInstance
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                            
	struct FAnimNode_Root                              AnimGraphNode_Root_77052BD4409664FC0AB1049BA1B36FE3;       
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_CDBB51A0489CC99483DCB8B3DAC2D417; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_D52967AE43174A92130032A375F2B388; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_17992ABD43AE90C6C2B8DB98581A1252; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_945732AB4D14124001B5A1BA5E44564E; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_F4BA0C0048749CF23EAD25A7E526522A; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_7F1FBFFB47979AF90A80D68AEAD0FAD4; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A6A6B59445A47D5422694A914F8E5C78; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_7D5A6C2040F63107E549D0B1DF378424; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_DDEBC5974DF4F3699C0679945890537D; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_FA594CA34CBC9C42A6E69FA8745F557D; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A561C51E4A4F43C0DF3DF482E5CD13EB; 
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_4AE760824BD6017B891F9B9406DE7A28; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_FE6EAEF84DDE4FD80ECD48950A8E3505; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_34B1E2574975F125F97E97ACEC9F97BD; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_2DF76C5B486E4CBCFF76528BEC8EC694; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_2F60C24C469A03CDA9C170B428307C95; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_5659CC3E44CBC29E51C86E91AC437612; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_5B458A5140F491F5105924BD9F3133B9; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_9090A73B44EDC2B417C8D6B3ECE24926; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_501FF711462B68208994E480E9D2764B; 
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_69B91A6443D64CADF3F57680FF0811F0; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_D7BB27CD4BB1F1BECB8D91B23643B57E; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_8856571D431A3F33B942A3BBB43DFC78; 
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_A966479A422137DBB17B59BA1453A4F5; 
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_39EE0F6B4117FE338C9FF089A783C117; 
	struct FAnimNode_ConvertComponentToLocalSpace      AnimGraphNode_ComponentToLocalSpace_3EBE36354B002BDA6AA8DC9438E29D12; 
	struct FAnimNode_ConvertLocalToComponentSpace      AnimGraphNode_LocalToComponentSpace_DC48599F4DC60D7A1AAB4CB718D668DB; 
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_FFEA601148F0CEF76AD0878171C47A5F; 
	struct FAnimNode_Root                              AnimGraphNode_StateResult_F20798C841C3FCA117794BAB32C53B34; 
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_72AC2F9A45E0BBB37244C7AADA0F167B; 
	struct FAnimNode_Slot                              AnimGraphNode_Slot_706F6FD847B91C06DC739B91C7E46CA1;       
	float                                              NewVar_1;                                                  

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass ABP_Transform_MiniTV.ABP_Transform_MiniTV_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_A6A6B59445A47D5422694A914F8E5C78();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_7D5A6C2040F63107E549D0B1DF378424();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_DDEBC5974DF4F3699C0679945890537D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_FA594CA34CBC9C42A6E69FA8745F557D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_7F1FBFFB47979AF90A80D68AEAD0FAD4();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_A561C51E4A4F43C0DF3DF482E5CD13EB();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_4AE760824BD6017B891F9B9406DE7A28();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_SequencePlayer_FE6EAEF84DDE4FD80ECD48950A8E3505();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_F4BA0C0048749CF23EAD25A7E526522A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_SequencePlayer_2DF76C5B486E4CBCFF76528BEC8EC694();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_SequencePlayer_5659CC3E44CBC29E51C86E91AC437612();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_945732AB4D14124001B5A1BA5E44564E();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_SequencePlayer_9090A73B44EDC2B417C8D6B3ECE24926();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_BlendSpacePlayer_69B91A6443D64CADF3F57680FF0811F0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_17992ABD43AE90C6C2B8DB98581A1252();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_SequencePlayer_8856571D431A3F33B942A3BBB43DFC78();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_SequencePlayer_A966479A422137DBB17B59BA1453A4F5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_BlendListByBool_39EE0F6B4117FE338C9FF089A783C117();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_ModifyBone_FFEA601148F0CEF76AD0878171C47A5F();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_D52967AE43174A92130032A375F2B388();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_ABP_Transform_MiniTV_AnimGraphNode_TransitionResult_CDBB51A0489CC99483DCB8B3DAC2D417();
	void ExecuteUbergraph_ABP_Transform_MiniTV(int EntryPoint);
};


}

