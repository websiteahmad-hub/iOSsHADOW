// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_MultiLevelItem_type
{
	int                                                GroupID_5_3BB8908055FC2C9220DCD7860F82E614;                
	int                                                ItemID_6_3DFE91004236D48E3BE164890D1603F4;                 
	int                                                Level_7_095F68007727584A67D53A8602D3389C;                  
	int                                                ShowType_9_3E567AC015AE254347747629022EADE5;               
	int                                                ModuleID_10_694726C0482B6E1930A79BE60AFA04E4;              
};

}

