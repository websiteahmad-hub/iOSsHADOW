// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_UGCTagConfig_type
{
	int                                                ID_1_258BBD00560A8612515BDDE7062EF814;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     Name_2_55243A006C6C3A8E7A4CA7A80EF98215;                   
	int                                                Sort_3_0BD543C02E3310477A47818F0EF960B4;                   
	int                                                Type_4_2BF0A24050CE8CA97A46420A0EF98645;                   
	int                                                isInvisible_5_00CB1A007C6717682102A3F604B5E795;            
	unsigned char                                      UnknownData01[0x4];                                        
	TArray<float>                                      Color_af_10_3C1CC300463C0CF81A78279D04189D16;              
	int                                                RankTab_11_5284A28043890E20486A507C0427E5E2;               
	int                                                SortType_12_21FC6C40713D57AF171F36CA00B75905;              
	int                                                TagDescriptionKey_13_184B4C000C25566421DCB2250A0A98F9;     
	int                                                PrimaryType_15_6B6A1B40702E388F4290E43D07056EB5;           
	int                                                Filterable_16_7ACFF84048E129CF55F28D7404307335;            
	unsigned char                                      UnknownData02[0x4];                                        
	struct FString                                     VideoImage_17_24DED0400A937F9528E1550D06C73E55;            
	struct FString                                     VideoUrl_18_2895244016CF99BB5B3A04110986B58C;              
	struct FString                                     FeaturesTag_19_10F690801BB93CB6752741B6030C5027;           
};

}

