// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_NATION_SWITCH
{
	bool                                               NationRankSwitch_0_90EC58964A07013E18D9C4A0C24C6D72;       
	bool                                               NationAllSwitch_1_FFDC7E7C4281022AAE40A5B03DD5CE4A;        
	bool                                               NationBattleSwitch_2_DCD8C0084AAD46192D3CA48FD5FCC651;     
	bool                                               Updated_3_5B3974684ED721353E91AA966D7347A5;                
};

}

