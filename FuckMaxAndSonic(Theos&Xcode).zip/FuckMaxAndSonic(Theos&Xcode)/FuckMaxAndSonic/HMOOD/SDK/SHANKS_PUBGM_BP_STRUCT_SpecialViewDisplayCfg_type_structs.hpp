// HMOOD__TG@i_8_f
 

#pragma once

 
 
 
 
namespace SDK
{
 
 
 

 
 
struct FBP_STRUCT_SpecialViewDisplayCfg_type
{
	struct FString                                     EndTime_0_6EED5F8051C5B6F60C0BFDEE05E37A55;                
	int                                                ID_1_3C7B9940705DF9435F10A9820AAD6624;                     
	unsigned char                                      UnknownData00[0x4];                                        
	struct FString                                     MaxVersion_2_690C19007669EAF67B5A3A7B01AE5E2E;             
	struct FString                                     MinVersion_3_07D2D880182740482D85FA9C01AE5ACE;             
	struct FString                                     StartTime_4_69F69D40696096291B2F46C0024FDB35;              
	TArray<int>                                        ViewIDs_a_5_1797CCC07106D24518969E16066BCC01;              
	int                                                key_6_2D2688404B2CC80346F4E9B10AD65E69;                    
	int                                                Enable_7_5F02A7C058E1AB27297A3EFB065ED645;                 
};

}

