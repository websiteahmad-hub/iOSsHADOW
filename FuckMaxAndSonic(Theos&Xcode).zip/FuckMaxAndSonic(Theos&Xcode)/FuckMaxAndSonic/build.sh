#!/bin/bash
# ============================================================
#  HMOOD / FuckMaxAndSonic - Theos Fast Build Script
# ============================================================

set -o pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd)"
[ -z "$PROJECT_DIR" ] && PROJECT_DIR="$(pwd)"

export THEOS="${THEOS:-$HOME/theos}"
JOBS="${JOBS:-$(sysctl -n hw.ncpu 2>/dev/null || echo 8)}"

RED='\033[1;31m'; GREEN='\033[1;32m'; YELLOW='\033[1;33m'
CYAN='\033[1;36m'; BOLD='\033[1m'; RESET='\033[0m'

banner() {
    echo -e "${CYAN}${BOLD}============================================================${RESET}"
    echo -e "${CYAN}${BOLD}   HMOOD  -  Theos Builder${RESET}"
    echo -e "${CYAN}${BOLD}============================================================${RESET}"
    echo -e "  Project : ${YELLOW}${PROJECT_DIR}${RESET}"
    echo -e "  Theos   : ${YELLOW}${THEOS}${RESET}"
    echo -e "  CPUs    : ${YELLOW}${JOBS}${RESET}"
    echo -e "${CYAN}${BOLD}------------------------------------------------------------${RESET}"
}

die() { echo -e "${RED}[X] $1${RESET}"; exit 1; }

check_env() {
    [ -f "$PROJECT_DIR/Makefile" ] || die "لا يوجد Makefile في ${PROJECT_DIR}"
    [ -d "$THEOS/makefiles" ] || die "Theos غير موجود في ${THEOS}"
    case "$PROJECT_DIR" in
        *" "*) die "المسار يحتوي مسافات - Theos لا يدعمها" ;;
    esac
}

report() {
    local rc=$1
    echo ""
    if [ $rc -eq 0 ]; then
        echo -e "${GREEN}${BOLD}[OK] نجح البناء بنجاح!${RESET}"
        local deb=$(ls -t packages/*.deb 2>/dev/null | head -1)
        [ -n "$deb" ] && echo -e "${GREEN}    الحزمة: ${deb}  ($(du -h "$deb" | cut -f1))${RESET}"
        echo -e "${CYAN}    للتثبيت:  ./build.sh install <IP>${RESET}"
    else
        echo -e "${RED}${BOLD}[X] فشل البناء (رمز $rc)${RESET}"
        echo -e "${CYAN}    التفاصيل: ./build.sh verbose${RESET}"
    fi
    echo -e "${CYAN}${BOLD}============================================================${RESET}"
    exit $rc
}

build_fast() {
    banner
    echo -e "${GREEN}[>] بناء سريع (كاش مفعّل)${RESET}"
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    make -j"$JOBS" package
    report $?
}

build_clean() {
    banner
    echo -e "${YELLOW}[>] تنظيف كامل ثم بناء${RESET}"
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    make clean
    make -j"$JOBS" package
    report $?
}

build_dylib() {
    banner
    echo -e "${GREEN}[>] بناء dylib فقط (الأسرع)${RESET}"
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    make -j"$JOBS"
    report $?
}

build_verbose() {
    banner
    echo -e "${GREEN}[>] بناء مع تفاصيل كاملة${RESET}"
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    make -j"$JOBS" package 2>&1 | tee build.log
    report ${PIPESTATUS[0]}
}

install_pkg() {
    banner
    echo -e "${GREEN}[>] بناء + تثبيت (USB)${RESET}"
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    make -j"$JOBS" package install
    report $?
}

install_ssh() {
    local IP="${1:-}"
    [ -n "$IP" ] || { echo -e "${YELLOW}الاستخدام: ./build.sh install <IP>${RESET}"; exit 1; }
    banner
    echo -e "${GREEN}[>] بناء + تثبيت عبر SSH إلى ${IP}${RESET}"
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    make -j"$JOBS" package || die "فشل البناء"
    local DEB=$(ls -t packages/*.deb 2>/dev/null | head -1)
    [ -n "$DEB" ] || die "لم يتم العثور على .deb"
    local BASE=$(basename "$DEB")
    echo -e "${CYAN}[>] scp -> root@${IP}${RESET}"
    scp "$DEB" "root@${IP}:/tmp/" || die "فشل scp"
    echo -e "${CYAN}[>] dpkg -i${RESET}"
    ssh "root@${IP}" "dpkg -i /tmp/${BASE} && rm -f /tmp/${BASE} && echo 'jmpr respring'" || die "فشل التثبيت"
    echo -e "${GREEN}[OK] تم التثبيت. أعد تشغيل اللعبة.${RESET}"
}

status() {
    banner
    cd "$PROJECT_DIR" || die "المشروع غير موجود"
    echo -e "كائنات مبنية : ${GREEN}$(find .theos/obj -name '*.o' 2>/dev/null | wc -l | tr -d ' ')${RESET}"
    local deb=$(ls -t packages/*.deb 2>/dev/null | head -1)
    if [ -n "$deb" ]; then
        echo -e "آخر حزمة    : ${GREEN}${deb}${RESET}"
        echo -e "الحجم       : $(du -h "$deb" | cut -f1)"
        echo -e "التاريخ     : $(stat -f '%Sm' "$deb")"
    else
        echo -e "آخر حزمة    : ${RED}لا توجد${RESET}"
    fi
    local dylib=$(find .theos -name "HMOOD.dylib" 2>/dev/null | head -1)
    [ -n "$dylib" ] && echo -e "آخر dylib   : ${GREEN}${dylib} ($(du -h "$dylib" | cut -f1))${RESET}"
    echo ""
}

clean() {
    banner
    cd "$PROJECT_DIR" || die "تعذّر الدخول للمجلد"
    echo -e "${YELLOW}[>] تنظيف...${RESET}"
    make clean
    echo -e "${GREEN}[OK] تم${RESET}"
}

usage() {
    banner
    printf "\n  ${BOLD}الامر:${RESET}\n"
    printf "    ${GREEN}build${RESET}              بناء سريع + حزمة deb\n"
    printf "    ${GREEN}dylib${RESET}             بناء dylib فقط (الاسرع)\n"
    printf "    ${GREEN}verbose${RESET}            بناء مع حفظ الاخطاء في build.log\n"
    printf "    ${GREEN}clean-build${RESET}       تنظيف كامل ثم بناء\n"
    printf "    ${GREEN}install${RESET}           بناء + تثبيت USB\n"
    printf "    ${GREEN}install <IP>${RESET}       بناء + تثبيت على IP\n"
    printf "    ${GREEN}status${RESET}            حالة البناء\n"
    printf "    ${GREEN}clean${RESET}             تنظيف\n"
    printf "    ${GREEN}help${RESET}              هذه القائمة\n"
    printf "\n  ${BOLD}ملاحظات:${RESET}\n"
    printf "    * البناء الاول طويل (583 ملف SDK) — بعدها الكاش يجعله فوري\n"
    printf "    * لتغيير عدد CPUs:  JOBS=4 ./build.sh\n\n"
}

check_env

case "${1:-build}" in
    build|fast)     build_fast ;;
    dylib)          build_dylib ;;
    verbose)        build_verbose ;;
    clean-build)    build_clean ;;
    install)        install_pkg ;;
    ssh)            shift; install_ssh "$@" ;;
    status)         status ;;
    clean)          clean ;;
    help|-h|--help) usage ;;
    *)              echo -e "${RED}امر غير معروف: $1${RESET}"; usage; exit 1 ;;
esac